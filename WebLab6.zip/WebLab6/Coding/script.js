let questions = [
    {
        question: "What does HTML stand for?",
        options: ["Hyper Text Markup Language", "High Text Machine Language", "Hyper Tool Markup Language"],
        answer: 0
    },
    {
        question: "Which language is used for styling?",
        options: ["HTML", "CSS", "JavaScript"],
        answer: 1
    },
    {
        question: "Which language is used for interactivity?",
        options: ["CSS", "HTML", "JavaScript"],
        answer: 2
    }
];

let currentIndex = 0;
let score = 0;
let timeLeft = 10;
let timer;

// Shuffle questions (simple)
function shuffleQuestions() {
    questions.sort(function () {
        return Math.random() - 0.5;
    });
}

// Start timer
function startTimer() {
    timeLeft = 10;
    document.getElementById("time").innerHTML = timeLeft;

    timer = setInterval(function () {
        timeLeft--;
        document.getElementById("time").innerHTML = timeLeft;

        if (timeLeft === 0) {
            clearInterval(timer);
            document.getElementById("feedback").innerHTML = "Time's up!";
        }
    }, 1000);
}

// Display question
function displayQuestion() {
    clearInterval(timer);
    document.getElementById("feedback").innerHTML = "";
    document.getElementById("answers").innerHTML = "";

    let q = questions[currentIndex];
    document.getElementById("question").innerHTML = q.question;

    for (let i = 0; i < q.options.length; i++) {
        let btn = document.createElement("button");
        btn.innerHTML = q.options[i];
        btn.onclick = function () {
            checkAnswer(i);
        };
        document.getElementById("answers").appendChild(btn);
    }

    startTimer();
}

// Check answer
function checkAnswer(choice) {
    clearInterval(timer);

    if (choice === questions[currentIndex].answer) {
        alert("Correct Answer!");
        score++;
    } else {
        alert("Wrong Answer!");
    }

    document.getElementById("score").innerHTML = "Score: " + score;
}

// Next question
function nextQuestion() {
    currentIndex++;

    if (currentIndex < questions.length) {
        displayQuestion();
    } else {
        document.getElementById("question").innerHTML = "Quiz Finished!";
        document.getElementById("answers").innerHTML = "";
        document.getElementById("feedback").innerHTML = "Final Score: " + score;
    }
}

// Start Quiz
shuffleQuestions();
displayQuestion();
